# WidgetComposer — Main App Screens

This pack adds the nine main product screens beyond the onboarding sequence.

## Screens
1. `01-home.png` — Prompt composer and popular templates
2. `02-create-with-ai.png` — Prompt, styles, colors, size selector, generate action
3. `03-generating.png` — AI generation/loading state
4. `04-widget-ready.png` — Generated widget preview and actions
5. `05-customize.png` — Background, text/accent colors, radius, font controls
6. `06-templates.png` — Template gallery
7. `07-my-widgets.png` — Saved widgets
8. `08-add-to-home-screen.png` — Android placement instructions
9. `09-profile.png` — Profile, plan, history, preferences

## Folders
- `screens/`: individual screen crops, saved as PNGs at 2x source crop size.
- `components/widget-cards/`: widget artwork crops for visual reference.
- `components/ui-references/`: selected UI sections useful while implementing.
- `brand/`: copied logo/icon/splash reference assets when available.
- `references-original-nine-screen-contact-sheet.png`: original source image.

## Important
The nine screens and component crops are extracted from a flattened, AI-generated contact sheet. They are **visual references**, not source design files or production-ready screen assets. Some text and visual details may be slightly distorted in the source. For the actual React Native app, rebuild text, buttons, inputs, tabs, selection states, progress indicators, and widget content as native components. Use the extracted widget cards as references rather than assuming they are transparent layered assets.
